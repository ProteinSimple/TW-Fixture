Python runtime library for use with the Flatbuffersserialization format.


