High Level API
==============

This is the recommended API. See the :ref:`programming_guide` for
"prose" documentation of these (and other) APIs.


Tor
---
.. autoclass:: txtorcon.Tor


connect
-------

.. automethod:: txtorcon.controller.connect


launch
------

.. automethod:: txtorcon.controller.launch
