Tracking and Changing Live Tor State
====================================

.. comment::
	launch_tor is documented in txtorcon-launching.rst


TorState
--------
.. autoclass:: txtorcon.TorState


Circuit
-------
.. autoclass:: txtorcon.Circuit


Stream
------
.. autoclass:: txtorcon.Stream


Router
------
.. autoclass:: txtorcon.Router
