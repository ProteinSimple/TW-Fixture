try:
    from scard import *
except:
    from smartcard.scard._scard import *
